# Copy Style

- Lead with value
- Use active voice
- Keep sentences short


