// Local route overrides for rapid alignment. Keep this file in repo; values can remain empty.
// Example:
// export const ROUTE_OVERRIDES: Partial<Record<import("@/src/lib/route-map").RouteKey, string>> = {
//   seo_audit: "seo/run-audit",
// };

export const ROUTE_OVERRIDES: Partial<Record<import("@/src/lib/route-map").RouteKey, string>> = {};



