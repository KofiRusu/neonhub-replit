export default function Page(){return (<main className="p-8"><h1 className="text-2xl font-bold">messaging</h1><p className="text-muted-foreground">Stub page for messaging</p></main>)}
