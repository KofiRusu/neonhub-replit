"use client";
export default function StyleProbe() {
  return (
    <div className="fixed bottom-3 right-3 z-[999] rounded-lg bg-emerald-500/20 text-emerald-200 ring-1 ring-emerald-400/40 px-3 py-1 text-xs">
      Tailwind OK
    </div>
  );
}


